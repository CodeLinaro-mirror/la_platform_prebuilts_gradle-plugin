/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.tools.lint.client.api

import com.android.tools.lint.detector.api.Context
import com.android.tools.lint.detector.api.FileScanner
import com.android.tools.lint.detector.api.Issue
import com.android.tools.lint.detector.api.Location
import com.android.tools.lint.detector.api.Project
import java.io.File

/** Interface implemented by detectors interested in TOML files. */
interface TomlScanner : FileScanner {
  fun visitTomlDocument(context: TomlContext, document: LintTomlDocument)
}

class TomlContext(
  driver: LintDriver,
  project: Project,
  main: Project?,
  file: File,
  contents: CharSequence,
  val document: LintTomlDocument,
) : Context(driver, project, main, file, contents) {
  override val suppressCommentPrefix: String = SUPPRESS_JAVA_COMMENT_PREFIX

  fun getLocation(tomlValue: LintTomlValue): Location = tomlValue.getLocation()

  fun isSuppressedWithComment(cookie: Any, issue: Issue): Boolean {
    val location = getLocation(cookie)
    val start = location.start?.offset ?: 0
    val checkComments = containsCommentSuppress()
    return checkComments && isSuppressedWithComment(start, issue)
  }
}
